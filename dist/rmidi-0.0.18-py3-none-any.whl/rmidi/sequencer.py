
class sequencer:
    def __init__(self, filename = None):
        self.filename = filename
    
    