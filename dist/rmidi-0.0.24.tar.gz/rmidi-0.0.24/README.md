# rmidipy
Math Sequence to midi, 

The package will help in opening the midi files and geting modified it. 

For now it is developing stage, The functionality implemented is only of opening and closing of midi file. With same can convert sequence to midi file
