
X = ch_event_format.update(meta_event_format).update(sys_event_format)